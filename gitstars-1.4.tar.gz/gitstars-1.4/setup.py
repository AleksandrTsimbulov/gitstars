from setuptools import setup

setup(
    name='gitstars',
    version='1.4',
    description='a test task for getting a job',
    author='Aleksandr Tsimbulov',
    author_email='worktsa@yandex.ru',
    python_requires='>=3.6',
    packages=['tochka'],
    install_requires=[
        'requests>=2.18.4',
        'argparse>=1.1',
    ],
    entry_points={
        'console_scripts': ['gitstars=tochka.gitstars:main'],
    }
)
