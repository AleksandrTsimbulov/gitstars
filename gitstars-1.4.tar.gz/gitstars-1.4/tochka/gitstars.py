"""
The following script accepts the obligatory GitHub username argument from console and returns
a list of GitHub repositories, which are starred by the user with total number of repository stars.
Usage:
    console input: "script" "username"
    console output: "[('repository_url', total_number_of_stars), ...]"

The script uses the official GitHub REST API v3, not GitHub's GraphQL API v4.

Author Aleksandr Tsimbulov, 2018.02.19 v 1.4
"""


def main():
    import requests
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="The script takes GitHub username as a mandatory argument"
                                                 "and returns a list of user's starred repositories and "
                                                 "a number of their total stars. "
                                                 "Console input: gitstars GitHub_user. "
                                                 "Console output: [('repository_url', total_number_of_stars), ...]")
    parser.add_argument("GitHub_user", action='store', help="username for GitHub account", type=str)
    args = parser.parse_args()
    user_name = args.GitHub_user
    url = 'https://api.github.com'
    request_headers = {'Accept': 'application/vnd.github.v3+json'}
    req = requests.get(url=f'{url}/users/{user_name}/starred', headers=request_headers)
    # checking if the required user exists and available
    if req.status_code == 200:
        user_starred_reps = []
        for starred_repository in req.json():
            user_starred_reps.append((starred_repository['html_url'], starred_repository['stargazers_count']))
        sys.stdout.write(str(user_starred_reps))
        sys.exit()
    # if the user is not available:
    sys.stdout.write(f'User {user_name} is not found among GitHub users. Please check username spelling '
                     f'and try again later.\n'
                     f'There are a few other possible reasons that might cause this message:\n'
                     f'- the {user_name} account has been deleted from GitHub\n'
                     f'- GitHub service is temporary unavailable\n'
                     f'- you don not have necessary access permissions to network environment. Please, ask your network'
                     f' administrator for more information ')


if __name__ == '__main__':
    main()
