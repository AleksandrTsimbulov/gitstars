"""
The following script accepts the obligatory GitHub username argument from console and returns
a list of GitHub repositories, which are starred by the user with total number of repository stars.
Usage:
    console input: "script" "username"
    console output: "[('repository_url', total_number_of_stars), ...]"

The script uses the official GitHub REST API v3, not GitHub's GraphQL API v4.

Author Aleksandr Tsimbulov, 2018.02.19 v 1.3
"""


def main():
    import requests
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="The script takes GitHub username as a mandatory argument"
                                                 "and returns a list of user's starred repositories and "
                                                 "a number of their total stars. "
                                                 "Console input: gitstars GitHub_user. "
                                                 "Console output: [('repository_url', total_number_of_stars), ...]")
    parser.add_argument("GitHub_user", action='store', help="username for GitHub account", type=str)
    args = parser.parse_args()
    user_name = args.GitHub_user
    url = 'https://api.github.com'
    request_headers = {'Accept': 'application/vnd.github.v3+json'}
    req = requests.get(url=f'{url}/users/{user_name}/starred', headers=request_headers)
    if req.status_code == 200:
        user_starred_reps = []
        for starred_repository in req.json():
            user_starred_reps.append((starred_repository['html_url'], starred_repository['stargazers_count']))
        import sys
        sys.stdout.write(str(user_starred_reps))
        sys.exit()
    sys.stdout.write(f'Пользователь {user_name} не найден среди пользователей GitHub. Пожалуйста, проверьте '
                     f'правильность написания логина пользователя и повторите попытку.\n'
                     f'Другими причинами появления данного сообщения могут быть:\n'
                     f'- удаление пользователя с сервиса GitHub\n'
                     f'- временная недоступнотсь\n'
                     f'- сервиса GitHub, отсутствие необходимых прав доступа к сетевому окружению')


if __name__ == '__main__':
    main()
